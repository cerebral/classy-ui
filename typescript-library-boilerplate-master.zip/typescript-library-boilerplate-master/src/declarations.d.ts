// Declare stuff here

declare module 'some-module' {
  export function doStuff(): void;
}
